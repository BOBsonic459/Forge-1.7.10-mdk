package fr.bobsonic.mdkexample.utils;

public class Constants {
	public static final String MOD_ID = "examplemdk";
	public static final String MOD_NAME = "Example MDK";
	public static final String MOD_VERSION = "0.0.1";
	public static final String MOD_MC_VERSION = "[1.7.10]";
}
